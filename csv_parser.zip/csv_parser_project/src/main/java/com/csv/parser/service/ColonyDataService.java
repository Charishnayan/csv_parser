package com.csv.parser.service;

import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.csv.parser.entity.ColonyData;
import com.csv.parser.repository.ColonyDataRepository;
import java.io.InputStreamReader;
import java.net.URL;

@Service
public class ColonyDataService {
    @Autowired
    private ColonyDataRepository colonyDataRepository;

    public void saveColonyDataFromCsvUrl(String csvUrl) throws IOException {
        URL url = new URL(csvUrl);
        try (InputStream inputStream = url.openStream();
             InputStreamReader reader = new InputStreamReader(inputStream);
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader())) {

            for (CSVRecord record : csvParser) {
                ColonyData colonyData = new ColonyData();
                colonyData.setYear(Integer.parseInt(record.get("year")));
                colonyData.setMonth(record.get("months"));
                colonyData.setState(record.get("state"));
                colonyData.setColonyN(Integer.parseInt(record.get("colony_n")));
                colonyData.setColonyMax(Integer.parseInt(record.get("colony_max")));
                colonyData.setColonyLost(Integer.parseInt(record.get("colony_lost")));
                colonyData.setColonyLostPct(Double.parseDouble(record.get("colony_lost_pct")));
                colonyData.setColonyAdded(Integer.parseInt(record.get("colony_added")));
                colonyData.setColonyReno(Integer.parseInt(record.get("colony_reno")));
                colonyData.setColonyRenoPct(Double.parseDouble(record.get("colony_reno_pct")));

                colonyDataRepository.save(colonyData);
            }
        }
    }
}

