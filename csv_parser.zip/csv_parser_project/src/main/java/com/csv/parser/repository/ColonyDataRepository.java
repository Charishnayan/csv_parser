package com.csv.parser.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.csv.parser.entity.ColonyData;

@Repository
public interface ColonyDataRepository extends JpaRepository<ColonyData, Long> {
}

