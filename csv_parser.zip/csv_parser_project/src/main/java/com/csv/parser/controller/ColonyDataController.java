package com.csv.parser.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.csv.parser.service.ColonyDataService;

@RestController
@RequestMapping("/api/colony-data")
public class ColonyDataController {
    @Autowired
    private ColonyDataService colonyDataService;

    @PostMapping("/import-from-csv")
    public ResponseEntity<String> importDataFromCsv() {
        try {
            String csvUrl = "https://raw.githubusercontent.com/rfordatascience/tidytuesday/master/data/2022/2022-01-11/colony.csv";
            colonyDataService.saveColonyDataFromCsvUrl(csvUrl);
            return ResponseEntity.ok("Data imported successfully.");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to import data from CSV.");
        }
    }
}

