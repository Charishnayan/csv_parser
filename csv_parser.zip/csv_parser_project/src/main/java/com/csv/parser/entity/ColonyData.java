package com.csv.parser.entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

public class ColonyData {
	
	
	    @Id
	    @GeneratedValue
	    private Long id;
	    private Integer year;
	    private String month;
	    private String state;
	    private Integer colonyN;
	    private Integer colonyMax;
	    private Integer colonyLost;
	    private Double colonyLostPct;
	    private Integer colonyAdded;
	    private Integer colonyReno;
	    private Double colonyRenoPct;
	    
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public Integer getYear() {
			return year;
		}
		public void setYear(Integer year) {
			this.year = year;
		}
		public String getMonth() {
			return month;
		}
		public void setMonth(String month) {
			this.month = month;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		public Integer getColonyN() {
			return colonyN;
		}
		public void setColonyN(Integer colonyN) {
			this.colonyN = colonyN;
		}
		public Integer getColonyMax() {
			return colonyMax;
		}
		public void setColonyMax(Integer colonyMax) {
			this.colonyMax = colonyMax;
		}
		public Integer getColonyLost() {
			return colonyLost;
		}
		public void setColonyLost(Integer colonyLost) {
			this.colonyLost = colonyLost;
		}
		public Double getColonyLostPct() {
			return colonyLostPct;
		}
		public void setColonyLostPct(Double colonyLostPct) {
			this.colonyLostPct = colonyLostPct;
		}
		public Integer getColonyAdded() {
			return colonyAdded;
		}
		public void setColonyAdded(Integer colonyAdded) {
			this.colonyAdded = colonyAdded;
		}
		public Integer getColonyReno() {
			return colonyReno;
		}
		public void setColonyReno(Integer colonyReno) {
			this.colonyReno = colonyReno;
		}
		public Double getColonyRenoPct() {
			return colonyRenoPct;
		}
		public void setColonyRenoPct(Double colonyRenoPct) {
			this.colonyRenoPct = colonyRenoPct;
		}
		
		
		@Override
		public String toString() {
			return "ColonyData [id=" + id + ", year=" + year + ", month=" + month + ", state=" + state + ", colonyN="
					+ colonyN + ", colonyMax=" + colonyMax + ", colonyLost=" + colonyLost + ", colonyLostPct="
					+ colonyLostPct + ", colonyAdded=" + colonyAdded + ", colonyReno=" + colonyReno + ", colonyRenoPct="
					+ colonyRenoPct + "]";
		}
		
		
		public ColonyData(Long id, Integer year, String month, String state, Integer colonyN, Integer colonyMax,
				Integer colonyLost, Double colonyLostPct, Integer colonyAdded, Integer colonyReno,
				Double colonyRenoPct) {
			super();
			this.id = id;
			this.year = year;
			this.month = month;
			this.state = state;
			this.colonyN = colonyN;
			this.colonyMax = colonyMax;
			this.colonyLost = colonyLost;
			this.colonyLostPct = colonyLostPct;
			this.colonyAdded = colonyAdded;
			this.colonyReno = colonyReno;
			this.colonyRenoPct = colonyRenoPct;
		}
		public ColonyData() {
			super();
		}
	    
	    
	    

}
