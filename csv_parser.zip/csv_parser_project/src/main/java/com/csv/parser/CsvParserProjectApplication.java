package com.csv.parser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CsvParserProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CsvParserProjectApplication.class, args);
	}

}
