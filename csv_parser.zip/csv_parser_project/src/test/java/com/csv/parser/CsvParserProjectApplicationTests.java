package com.csv.parser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsvParserProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
